#!/usr/bin/env python3
import gzip
import hashlib
import json
import math
import os
import shutil
import time
import urllib.request
from collections import defaultdict, deque
from pathlib import Path

import numpy as np
import highspy

OUT = Path(os.environ.get('MIPLIB_IG_OUT', 'out/miplib-structural-presolve'))
OUT.mkdir(parents=True, exist_ok=True)
DATA = OUT / 'instances'
DATA.mkdir(parents=True, exist_ok=True)

TIME_LIMIT = float(os.environ.get('MIPLIB_IG_TIME_LIMIT', '15'))

INSTANCES = [
    {
        'name': 'mad',
        'url': 'https://miplib.zib.de/WebData/instances/mad.mps.gz',
        'expected': 0.0268,
        'family': 'mean-absolute-deviation / dense set-partitioning mixed-binary',
    },
    {
        'name': 'glass4',
        'url': 'https://miplib.zib.de/WebData/instances/glass4.mps.gz',
        'expected': 1200012599.972384,
        'family': 'nesting / sparse set-partitioning mixed-binary',
    },
    {
        'name': 'supportcase26',
        'url': 'https://miplib.zib.de/WebData/instances/supportcase26.mps.gz',
        'expected': 1745.123813,
        'family': 'precedence / sparse mixed-binary',
    },
    {
        'name': 'bppc4-08',
        'url': 'https://miplib.zib.de/WebData/instances/bppc4-08.mps.gz',
        'expected': 53.0,
        'family': 'bin-packing / set-partitioning mixed-binary',
    },
]


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def download_instance(spec):
    gz_path = DATA / f"{spec['name']}.mps.gz"
    mps_path = DATA / f"{spec['name']}.mps"
    req = urllib.request.Request(spec['url'], headers={'User-Agent': 'IsoGraph-MIPLIB-prototype/0.1'})
    with urllib.request.urlopen(req, timeout=60) as response, open(gz_path, 'wb') as out:
        shutil.copyfileobj(response, out)
    with gzip.open(gz_path, 'rb') as src, open(mps_path, 'wb') as dst:
        shutil.copyfileobj(src, dst)
    return {
        'mps_path': str(mps_path),
        'download_sha256': sha256(gz_path),
        'mps_sha256': sha256(mps_path),
        'bytes_gzip': gz_path.stat().st_size,
        'bytes_mps': mps_path.stat().st_size,
    }


def set_common_options(h, presolve='off'):
    h.setOptionValue('output_flag', False)
    h.setOptionValue('presolve', presolve)
    h.setOptionValue('threads', 1)
    h.setOptionValue('parallel', 'off')
    h.setOptionValue('random_seed', 0)
    h.setOptionValue('time_limit', TIME_LIMIT)
    h.setOptionValue('mip_rel_gap', 0.0)


def dimensions(h):
    return {
        'cols': int(h.getNumCol()),
        'rows': int(h.getNumRow()),
        'nonzeros': int(h.getNumNz()),
    }


def solve_model(model_or_path, presolve='off'):
    h = highspy.Highs()
    set_common_options(h, presolve=presolve)
    if isinstance(model_or_path, (str, os.PathLike)):
        status = h.readModel(str(model_or_path))
    else:
        status = h.passModel(model_or_path)
    if status != highspy.HighsStatus.kOk:
        raise RuntimeError(f'HiGHS load failed: {status}')
    t0 = time.perf_counter()
    h.run()
    wall = time.perf_counter() - t0
    info = h.getInfo()
    model_status = h.getModelStatus()
    optimal = model_status == highspy.HighsModelStatus.kOptimal
    objective = None
    if optimal or getattr(info, 'primal_solution_status', 0) > 0:
        try:
            objective = float(h.getObjectiveValue())
        except Exception:
            objective = None
    return {
        'status': h.modelStatusToString(model_status),
        'optimal': bool(optimal),
        'objective': objective,
        'dual_bound': safe_float(getattr(info, 'mip_dual_bound', None)),
        'gap': safe_float(getattr(info, 'mip_gap', None)),
        'nodes': safe_int(getattr(info, 'mip_node_count', None)),
        'lp_iterations': safe_int(getattr(info, 'simplex_iteration_count', None)),
        'highs_runtime_s': safe_float(h.getRunTime()),
        'wall_runtime_s': wall,
        'dimensions': dimensions(h),
    }


def safe_float(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else str(x)
    except Exception:
        return None


def safe_int(v):
    try:
        return int(v)
    except Exception:
        return None


def float_key(v):
    x = float(v)
    if math.isnan(x):
        return 'nan'
    if math.isinf(x):
        return '+inf' if x > 0 else '-inf'
    if x == 0.0:
        x = 0.0
    return x.hex()


def matrix_views(h):
    lp = h.getLp()
    n = int(lp.num_col_)
    m = int(lp.num_row_)
    start = list(lp.a_matrix_.start_)
    index = list(lp.a_matrix_.index_)
    value = list(lp.a_matrix_.value_)
    fmt = str(lp.a_matrix_.format_)
    cols = [[] for _ in range(n)]
    rows = [[] for _ in range(m)]
    if 'Colwise' in fmt or (len(start) == n + 1 and n != m):
        for j in range(n):
            for p in range(int(start[j]), int(start[j + 1])):
                i = int(index[p]); a = float(value[p])
                cols[j].append((i, a)); rows[i].append((j, a))
    elif 'Rowwise' in fmt or len(start) == m + 1:
        for i in range(m):
            for p in range(int(start[i]), int(start[i + 1])):
                j = int(index[p]); a = float(value[p])
                rows[i].append((j, a)); cols[j].append((i, a))
    else:
        raise RuntimeError(f'Unrecognized HiGHS matrix layout: format={fmt}, starts={len(start)}, n={n}, m={m}')
    for x in cols:
        x.sort()
    for x in rows:
        x.sort()
    integrality = list(lp.integrality_)
    if len(integrality) != n:
        integrality = [highspy.HighsVarType.kContinuous] * n
    return lp, cols, rows, integrality


def names(lp, kind, count):
    attr = 'col_names_' if kind == 'col' else 'row_names_'
    raw = list(getattr(lp, attr, []))
    if len(raw) == count:
        return [str(x) for x in raw]
    return [f'{kind}{i}' for i in range(count)]


def type_key(t):
    return str(t)


def exact_row_intersection_pass(h):
    lp, cols, rows, integrality = matrix_views(h)
    m = int(lp.num_row_)
    row_names = names(lp, 'row', m)
    groups = defaultdict(list)
    for i in range(m):
        sig = tuple((j, float_key(a)) for j, a in rows[i])
        groups[sig].append(i)
    changed = []
    delete = []
    for sig, g in groups.items():
        if len(g) < 2:
            continue
        rep = g[0]
        low = max(float(lp.row_lower_[i]) for i in g)
        up = min(float(lp.row_upper_[i]) for i in g)
        if low > up:
            raise RuntimeError(f'Identical-row intersection infeasible in rows {g}: {low}>{up}')
        old_low = float(lp.row_lower_[rep]); old_up = float(lp.row_upper_[rep])
        h.changeRowBounds(rep, low, up)
        delete.extend(g[1:])
        changed.append({
            'representative': row_names[rep],
            'members': [row_names[i] for i in g],
            'old_bounds': [old_low, old_up],
            'intersection_bounds': [low, up],
            'removed_rows': len(g) - 1,
            'proof': 'Rows have exactly identical coefficient incidence; replacing them by the intersection of their activity intervals is logically equivalent.',
        })
    if delete:
        arr = np.array(sorted(set(delete)), dtype=np.int32)
        h.deleteRows(len(arr), arr)
    return changed


def sum_lower(values):
    if any(math.isinf(v) and v < 0 for v in values):
        return -highspy.kHighsInf
    return float(sum(values))


def sum_upper(values):
    if any(math.isinf(v) and v > 0 for v in values):
        return highspy.kHighsInf
    return float(sum(values))


def exact_parallel_column_pass(h):
    lp, cols, rows, integrality = matrix_views(h)
    n = int(lp.num_col_)
    col_names = names(lp, 'col', n)
    groups = defaultdict(list)
    for j in range(n):
        t = type_key(integrality[j])
        if not (t.endswith('kContinuous') or t.endswith('kInteger')):
            continue
        sig = (
            t,
            float_key(lp.col_cost_[j]),
            tuple((i, float_key(a)) for i, a in cols[j]),
        )
        groups[sig].append(j)
    changed = []
    delete = []
    for sig, g in groups.items():
        if len(g) < 2:
            continue
        rep = g[0]
        lows = [float(lp.col_lower_[j]) for j in g]
        ups = [float(lp.col_upper_[j]) for j in g]
        new_low = sum_lower(lows)
        new_up = sum_upper(ups)
        h.changeColBounds(rep, new_low, new_up)
        delete.extend(g[1:])
        changed.append({
            'representative': col_names[rep],
            'members': [col_names[j] for j in g],
            'type': sig[0],
            'objective_coefficient': float(lp.col_cost_[rep]),
            'aggregate_bounds': [new_low, new_up],
            'removed_columns': len(g) - 1,
            'proof': 'Columns have exactly identical constraint coefficients, objective coefficient, and ordinary interval variable type; replacing them by their sum preserves every row activity, objective contribution, and the attainable interval/integer-sum domain.',
        })
    if delete:
        arr = np.array(sorted(set(delete)), dtype=np.int32)
        h.deleteCols(len(arr), arr)
    return changed


def apply_structural_closure(h, max_rounds=20):
    rounds = []
    total_rows = 0
    total_cols = 0
    for r in range(max_rounds):
        before = dimensions(h)
        row_changes = exact_row_intersection_pass(h)
        col_changes = exact_parallel_column_pass(h)
        after = dimensions(h)
        removed_rows = before['rows'] - after['rows']
        removed_cols = before['cols'] - after['cols']
        if row_changes or col_changes:
            rounds.append({
                'round': r + 1,
                'before': before,
                'after': after,
                'row_intersections': row_changes,
                'parallel_column_aggregations': col_changes,
            })
            total_rows += removed_rows
            total_cols += removed_cols
        if removed_rows == 0 and removed_cols == 0:
            break
    return {
        'rounds': rounds,
        'removed_rows': total_rows,
        'removed_cols': total_cols,
        'final_dimensions': dimensions(h),
    }


def connected_components(h):
    lp, cols, rows, integrality = matrix_views(h)
    n = int(lp.num_col_); m = int(lp.num_row_)
    seen_c = [False] * n
    seen_r = [False] * m
    comps = []
    for start_c in range(n):
        if seen_c[start_c]:
            continue
        cq = deque([start_c]); seen_c[start_c] = True
        cc = []; rr = []
        while cq:
            j = cq.popleft(); cc.append(j)
            for i, _ in cols[j]:
                if not seen_r[i]:
                    seen_r[i] = True; rr.append(i)
                    for k, _ in rows[i]:
                        if not seen_c[k]:
                            seen_c[k] = True; cq.append(k)
        comps.append({'cols': len(cc), 'rows': len(rr), 'nonzeros': sum(len(cols[j]) for j in cc)})
    for i in range(m):
        if not seen_r[i]:
            comps.append({'cols': 0, 'rows': 1, 'nonzeros': 0})
    comps.sort(key=lambda x: (x['cols'] + x['rows'], x['nonzeros']), reverse=True)
    nontrivial = [c for c in comps if c['cols'] and c['rows']]
    return {
        'component_count': len(comps),
        'nontrivial_component_count': len(nontrivial),
        'largest_components': comps[:12],
        'exact_factorization': len(nontrivial) > 1,
        'proof': 'Disconnected components of the row-variable incidence graph share no constraint variables; with an additive linear objective and independent variable bounds, their feasible sets and objective contributions factor exactly.' if len(nontrivial) > 1 else None,
    }


def hsh(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()).hexdigest()[:24]


def wl_structural_candidates(h, rounds=6):
    lp, cols, rows, integrality = matrix_views(h)
    n = int(lp.num_col_); m = int(lp.num_row_)
    ccol = [hsh(['c', type_key(integrality[j]), float_key(lp.col_lower_[j]), float_key(lp.col_upper_[j]), float_key(lp.col_cost_[j])]) for j in range(n)]
    crow = [hsh(['r', float_key(lp.row_lower_[i]), float_key(lp.row_upper_[i])]) for i in range(m)]
    for _ in range(rounds):
        ncol = [hsh(['c', ccol[j], sorted((float_key(a), crow[i]) for i, a in cols[j])]) for j in range(n)]
        nrow = [hsh(['r', crow[i], sorted((float_key(a), ccol[j]) for j, a in rows[i])]) for i in range(m)]
        ccol, crow = ncol, nrow
    col_groups = defaultdict(list)
    for j, c in enumerate(ccol): col_groups[c].append(j)
    row_groups = defaultdict(list)
    for i, c in enumerate(crow): row_groups[c].append(i)
    col_names = names(lp, 'col', n); row_names = names(lp, 'row', m)
    cg = [[col_names[j] for j in g] for g in col_groups.values() if len(g) > 1]
    rg = [[row_names[i] for i in g] for g in row_groups.values() if len(g) > 1]
    cg.sort(key=len, reverse=True); rg.sort(key=len, reverse=True)
    return {
        'rounds': rounds,
        'variable_candidate_classes': len(cg),
        'variable_candidates': sum(len(g) for g in cg),
        'largest_variable_classes': cg[:10],
        'row_candidate_classes': len(rg),
        'row_candidates': sum(len(g) for g in rg),
        'largest_row_classes': rg[:10],
        'authority': 'LEAD_ONLY',
        'note': 'Equal refinement colors are structural-candidate evidence only. They are not treated as variable identity, automorphism, dominance, or a legal quotient without an independent exact proof.',
    }


def objective_close(a, b):
    if a is None or b is None:
        return None
    return abs(a - b) <= 1e-7 * max(1.0, abs(a), abs(b))


def expected_close(a, b):
    return objective_close(a, b)


def run_one(spec):
    dl = download_instance(spec)
    path = dl['mps_path']

    original = highspy.Highs()
    set_common_options(original, presolve='on')
    if original.readModel(path) != highspy.HighsStatus.kOk:
        raise RuntimeError(f"Failed to read {spec['name']}")
    original_dims = dimensions(original)

    # Conventional HiGHS presolve is the frozen baseline. IsoGraph-style work starts only after this call.
    presolver = highspy.Highs()
    set_common_options(presolver, presolve='on')
    presolver.readModel(path)
    ps = presolver.presolve()
    presolved_model = presolver.getPresolvedModel()
    presolved_lp = presolved_model.lp_
    presolved_dims = {
        'cols': int(presolved_lp.num_col_),
        'rows': int(presolved_lp.num_row_),
        'nonzeros': int(len(presolved_lp.a_matrix_.value_)),
    }
    presolved_path = OUT / f"{spec['name']}.highs-presolved.mps"
    presolver.writePresolvedModel(str(presolved_path))

    baseline_residual = solve_model(presolved_model, presolve='off')

    reduced = highspy.Highs()
    set_common_options(reduced, presolve='off')
    if reduced.passModel(presolved_model) != highspy.HighsStatus.kOk:
        raise RuntimeError('Failed to pass presolved model')
    before_structure = {
        'components': connected_components(reduced),
        'wl_candidates': wl_structural_candidates(reduced),
    }
    closure = apply_structural_closure(reduced)
    after_structure = {
        'components': connected_components(reduced),
        'wl_candidates': wl_structural_candidates(reduced),
    }
    reduced_path = OUT / f"{spec['name']}.ig-reduced.mps"
    reduced.writeModel(str(reduced_path))

    # Solve the exact reduced residual with conventional presolve disabled so any difference is attributable to the structural pass.
    t0 = time.perf_counter()
    reduced.run()
    reduced_wall = time.perf_counter() - t0
    ri = reduced.getInfo(); rs = reduced.getModelStatus()
    reduced_solve = {
        'status': reduced.modelStatusToString(rs),
        'optimal': rs == highspy.HighsModelStatus.kOptimal,
        'objective': float(reduced.getObjectiveValue()) if rs == highspy.HighsModelStatus.kOptimal or getattr(ri, 'primal_solution_status', 0) > 0 else None,
        'dual_bound': safe_float(getattr(ri, 'mip_dual_bound', None)),
        'gap': safe_float(getattr(ri, 'mip_gap', None)),
        'nodes': safe_int(getattr(ri, 'mip_node_count', None)),
        'lp_iterations': safe_int(getattr(ri, 'simplex_iteration_count', None)),
        'highs_runtime_s': safe_float(reduced.getRunTime()),
        'wall_runtime_s': reduced_wall,
        'dimensions': dimensions(reduced),
    }

    original_solve = solve_model(path, presolve='on')
    objective_match = objective_close(baseline_residual['objective'], reduced_solve['objective']) if baseline_residual['optimal'] and reduced_solve['optimal'] else None
    expected_match = expected_close(reduced_solve['objective'], spec['expected']) if reduced_solve['optimal'] else None

    exact_reductions = closure['removed_rows'] + closure['removed_cols']
    factorization = after_structure['components']['exact_factorization']
    if exact_reductions:
        signal = 'POSITIVE_EXACT_POST_PRESOLVE_REDUCTION'
    elif factorization:
        signal = 'POSITIVE_EXACT_FACTORIZATION_SIGNAL'
    elif after_structure['wl_candidates']['variable_candidate_classes'] or after_structure['wl_candidates']['row_candidate_classes']:
        signal = 'STRUCTURAL_LEAD_ONLY'
    else:
        signal = 'NO_POST_PRESOLVE_SIGNAL'

    return {
        'name': spec['name'],
        'family': spec['family'],
        'source_url': spec['url'],
        'expected_objective': spec['expected'],
        'download': dl,
        'original_dimensions': original_dims,
        'highs_presolve_status': str(ps),
        'presolved_dimensions': presolved_dims,
        'baseline_residual_solve': baseline_residual,
        'structural_before': before_structure,
        'structural_closure': closure,
        'structural_after': after_structure,
        'reduced_solve': reduced_solve,
        'original_default_solve': original_solve,
        'objective_match_baseline_vs_reduced': objective_match,
        'expected_objective_match': expected_match,
        'signal': signal,
    }


def markdown_report(result):
    lines = [
        '# MIPLIB structural presolve prototype — result',
        '',
        f"**HiGHS:** {result['highs_version']}",
        f"**Instances:** {len(result['instances'])}",
        f"**Disposition:** {result['disposition']}",
        '',
        'The experiment applies the fixed structural profile only **after HiGHS presolve**. Exact reductions are limited to logically equivalent identical-row interval intersection and exact aggregation of ordinary interval variables with identical row incidence and objective coefficient. WL/refinement classes are leads only.',
        '',
        '| Instance | HiGHS presolved | IG reduced | Exact Δ rows | Exact Δ cols | Components | WL var classes | Signal |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |',
    ]
    for x in result['instances']:
        p=x['presolved_dimensions']; r=x['structural_closure']['final_dimensions']; c=x['structural_after']['components']; w=x['structural_after']['wl_candidates']
        lines.append(f"| {x['name']} | {p['rows']}×{p['cols']} | {r['rows']}×{r['cols']} | {x['structural_closure']['removed_rows']} | {x['structural_closure']['removed_cols']} | {c['nontrivial_component_count']} | {w['variable_candidate_classes']} | {x['signal']} |")
    lines += ['', '## Solve checks', '']
    for x in result['instances']:
        b=x['baseline_residual_solve']; r=x['reduced_solve']; o=x['original_default_solve']
        lines += [
            f"### {x['name']}",
            '',
            f"- current MIPLIB target objective: `{x['expected_objective']}`",
            f"- original + default HiGHS presolve: `{o['status']}`, objective `{o['objective']}`, wall `{o['wall_runtime_s']:.4f}s`, nodes `{o['nodes']}`",
            f"- exported HiGHS residual, presolve off: `{b['status']}`, objective `{b['objective']}`, wall `{b['wall_runtime_s']:.4f}s`, nodes `{b['nodes']}`",
            f"- structural residual, presolve off: `{r['status']}`, objective `{r['objective']}`, wall `{r['wall_runtime_s']:.4f}s`, nodes `{r['nodes']}`",
            f"- baseline/reduced objective match when both optimal: `{x['objective_match_baseline_vs_reduced']}`",
            f"- reduced/current-target objective match when optimal: `{x['expected_objective_match']}`",
            '',
        ]
    lines += [
        '## Interpretation boundary',
        '',
        '- A positive exact reduction means the fixed algebraic rule still found eliminable structure after the selected HiGHS presolve run.',
        '- Exact graph factorization means the residual row-variable incidence graph contains multiple disconnected nontrivial components; it does not by itself prove the incumbent solver fails to exploit them internally.',
        '- WL candidate classes are **not reductions**. They are candidates for later exact symmetry/equivalence/dominance work.',
        '- A null result is useful: it falsifies these low-cost structural rules on that residual and tells the next pass to target deeper semantic structure rather than duplicate ordinary presolve.',
        '- This is a prototype structural pass, not a Core 0.21-qualified IsoGraph rendering or a claim of a new MIP presolve theorem.',
        '',
    ]
    return '\n'.join(lines)


def main():
    results = []
    errors = []
    for spec in INSTANCES:
        try:
            print(f"=== {spec['name']} ===", flush=True)
            r = run_one(spec)
            results.append(r)
            print(json.dumps({
                'name': r['name'],
                'presolved': r['presolved_dimensions'],
                'reduced': r['structural_closure']['final_dimensions'],
                'removed_rows': r['structural_closure']['removed_rows'],
                'removed_cols': r['structural_closure']['removed_cols'],
                'components': r['structural_after']['components']['nontrivial_component_count'],
                'wl_var_classes': r['structural_after']['wl_candidates']['variable_candidate_classes'],
                'signal': r['signal'],
            }, indent=2), flush=True)
        except Exception as e:
            errors.append({'name': spec['name'], 'error': repr(e)})
            print(f"ERROR {spec['name']}: {e!r}", flush=True)
    objective_failures = [x['name'] for x in results if x['objective_match_baseline_vs_reduced'] is False or x['expected_objective_match'] is False]
    disposition = 'PASS' if not errors and not objective_failures and len(results) == len(INSTANCES) else 'FAIL'
    result = {
        'experiment': 'miplib-structural-presolve-prototype-0.1',
        'date': '2026-10-06',
        'highs_version': highspy.Highs().version(),
        'time_limit_s_per_solve': TIME_LIMIT,
        'fixed_profile': [
            'exact identical-row interval intersection',
            'exact identical-column aggregation for ordinary continuous/integer interval variables with identical objective coefficient',
            'exact disconnected-component detection',
            'six-round coefficient-aware bipartite refinement for LEAD_ONLY structural classes',
        ],
        'instances': results,
        'errors': errors,
        'objective_failures': objective_failures,
        'summary': {
            'instances_completed': len(results),
            'instances_with_exact_post_presolve_reduction': sum((x['structural_closure']['removed_rows'] + x['structural_closure']['removed_cols']) > 0 for x in results),
            'instances_with_exact_factorization_signal': sum(x['structural_after']['components']['exact_factorization'] for x in results),
            'instances_with_wl_leads': sum((x['structural_after']['wl_candidates']['variable_candidate_classes'] + x['structural_after']['wl_candidates']['row_candidate_classes']) > 0 for x in results),
            'total_post_presolve_rows_removed': sum(x['structural_closure']['removed_rows'] for x in results),
            'total_post_presolve_cols_removed': sum(x['structural_closure']['removed_cols'] for x in results),
        },
        'disposition': disposition,
    }
    (OUT / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    (OUT / 'SUMMARY.md').write_text(markdown_report(result) + '\n')
    print(json.dumps({'disposition': disposition, 'summary': result['summary'], 'errors': errors, 'objective_failures': objective_failures}, indent=2))
    if disposition != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
